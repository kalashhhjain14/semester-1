#include <stdio.h>

int main() {
    printf("GLS Institute of Computer Applications");
    return 0;
}
