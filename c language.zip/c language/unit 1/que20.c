#include <stdio.h>

int main() {
    printf("Name: John Doe\nContact: 1234567890\nAddress: Ahmedabad, Gujarat");
    return 0;
}
