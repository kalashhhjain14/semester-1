#include <stdio.h>

int main() {
    printf("hello\n");
    printf("GLS University");
    return 0;
}
