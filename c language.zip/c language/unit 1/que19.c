#include <stdio.h>

int main() {
    printf("Name: John Doe\n");
    printf("Contact: 1234567890\n");
    printf("Address: Ahmedabad, Gujarat");
    return 0;
}
