#include <stdio.h>

int main() {
    printf("GLS University");
    return 0;
}
