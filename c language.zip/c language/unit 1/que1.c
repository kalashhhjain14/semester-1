#include <stdio.h>

int main() {
    // Display message
    printf("GLS University\n");
    return 0;
}
