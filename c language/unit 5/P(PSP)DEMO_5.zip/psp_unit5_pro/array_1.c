#include<stdio.h>

void main()
{
	float num[5]={1.2, 3.4,5.6,7.8,5.4}
	int a[5]={10,34,56,7,21};
	char name[5]={'n','e','h','a'};
	
	int i;
	
	for(i=0;i<5;i++)
	{
		printf("%c",name[i]);
	}
	/*	
	//int x[5] = { 1,22,13,44,55 };
	
	int x[5];

	x[0] = 25;
	x[1] = 11;
	x[2] = 36;
	x[3] = 48;
	x[4] = 9;

	printf("%d\n",x[0]);
	printf("%d\n",x[1]);
	printf("%d\n",x[2]);
	printf("%d\n",x[3]);
	printf("%d\n",x[4]);*/
}



