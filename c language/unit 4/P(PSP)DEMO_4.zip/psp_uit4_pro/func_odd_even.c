#include<stdio.h>
void odd_even(int,int);//function declration

int main()
{
	//function calling
	odd_even(1,15);
	printf("\n");
	return 0;
}

//function defination
void odd_even(int s,int e)
{
	for(i=s;i<=e;i++)
	{
		if(i%2==0)
			printf("even")
	
		else
			odd
	}
}







