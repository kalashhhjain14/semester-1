#include<stdio.h>
void fy_im_divb(); //function declration

int main()
{
	fy_im_divb(); //function calling
	printf("\n\n hello ");
	printf("\n\n hii");
	fy_im_divb();
	printf("\n");
	return 0;
}

//function defination
void fy_im_divb()
{
	printf("\n hello fy im div b");
}



