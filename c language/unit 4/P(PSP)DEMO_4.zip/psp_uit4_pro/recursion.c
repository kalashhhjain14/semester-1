#include<stdio.h>
void neha();

int main()
{
	neha();
}

void neha()
{
	printf("\n hii neha");
	neha();
}