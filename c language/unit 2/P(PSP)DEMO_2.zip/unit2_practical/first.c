#include<stdio.h>
void main()
{
	int a,b,sum;
	a=10,b=20;
	sum=a+b;
	printf("\n value of a : %d",a);
	printf("\n value of b : %d",b);
	printf("\n value of sum : %d",sum);
	
	//return 0;
}
