#include<stdio.h>

int main()
{
	int a=10,b=20,c=30,ans;

	
	ans = a * b + c;

	printf("\n %d \n",ans);


	ans = a * (b + c);

	printf("\n %d \n",ans);


	return 0;

}
	

	