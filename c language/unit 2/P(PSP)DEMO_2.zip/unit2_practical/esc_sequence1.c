//this program is printing pyramid using escape sequence
#include<stdio.h>

int main()
{
	
	printf("*\n");
	printf("*\t*\n");
	printf("*\t*\t*\n");
	return 0;
	
}
