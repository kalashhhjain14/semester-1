#include <stdio.h>
int main()
{

	int x = 2;
	printf("x = %d\n",x);
	x<<=3;
	printf("x = %d\n",x);
}
	
