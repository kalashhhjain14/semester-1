#include<stdio.h>

int main()
{
	int a;
	float b;
	char c;
	//bool d;

	printf("\n size of int = %lu",sizeof(a));
	printf("\n size of float = %lu",sizeof(b));
	printf("\n size of char = %lu",sizeof(c));


	printf("\n");
	return 0;
}