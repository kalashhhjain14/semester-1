//this program is printing pyramid using escape sequence
#include<stdio.h>

int main()
{
	
	printf("*\n*\t*\n*\t*\t*\n");
	return 0;
	
}
