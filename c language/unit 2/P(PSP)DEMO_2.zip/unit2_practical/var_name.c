#include<stdio.h>

void main()
{
	int Num = 20;
	int @ab = 30;
	//int 5av = 40;
	//int x av = 50;

	printf("%d\n", Num);
	printf("%d\n", @ab);
	//printf("%d\n", 5av);
	//printf("%d\n", x av);
	
	
}
