#include<stdio.h>

void main()
{
	float cent,feh=40;
	cent=((feh-32)*5)/9;

	printf("\n cent=%f,feh=%f \n\n\n",cent,feh);	
}




