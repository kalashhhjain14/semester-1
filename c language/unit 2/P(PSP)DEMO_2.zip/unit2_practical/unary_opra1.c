#include<stdio.h>

void main()
{
	int a = 10;
	double b = 20.25368;

	printf("sizeof(a) = %ld\n", sizeof(a));
	printf("sizeof(b) = %ld\n", sizeof(b));
	printf("Address of(a) = %p\n", &a);
	printf("Address of(b) = %p\n", &b);
			
}

