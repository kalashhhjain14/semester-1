#include<stdio.h>
void main()
{
	float a,b,sum;
		
	printf("\n enter the value of a :");
	scanf("%f",&a);
	printf("\n enter the value of b :");
	scanf("%f",&b);
	sum=a+b;

	printf("\n value of a : %0.2f",a);
	printf("\n value of b : %f",b);
	printf("\n value of sum : %f",sum);
	printf("\n");
	//return 0;
}
