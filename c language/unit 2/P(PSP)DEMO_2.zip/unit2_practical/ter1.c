#include<stdio.h>

int main()
{
	int a=100,b=18,ans;

	a>b?printf("\n a is bigger"):printf("\n b is bigger");

	ans=a>b?a:b;
	
	printf("\n biggest value=%d",ans);
	printf("\n\n\n\n");
	return 0;
}

