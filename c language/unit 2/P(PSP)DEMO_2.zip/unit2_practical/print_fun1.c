#include<stdio.h>

void main()
{
	
	int a = 20;
	int b = 10;
	float c = 123.456789;
	printf("\n\n\n\n%d\n\n\n\n",ans);
	printf("\n%2s","ABCD");
	/*printf("\n\n%.3s","ABCD");

	printf("\n %6d", a-b);
	printf("\n\n %*d",10,a-b);

	printf("\n %.1f",c);
	printf("\n %.2f\n",c);*/
}
