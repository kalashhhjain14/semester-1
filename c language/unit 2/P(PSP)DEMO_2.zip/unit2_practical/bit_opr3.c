#include <stdio.h>
int main()
{

	int x = 10;
	int y = 06;
	int z = x & y;
	int k = x | y;
	int a = x ^ y;  //xor
	int b = ~x;
	x>>=1;
	y<<=1;
	printf("x & y = %d\n",z);
	printf("x | y = %d\n",k);
	printf("x ^ y = %d\n",a);
	printf("~x = %d\n",b);
	printf("x>>=1 = %d\n",x);
	printf("y<<=2 = %d\n",y);
	
}
	
