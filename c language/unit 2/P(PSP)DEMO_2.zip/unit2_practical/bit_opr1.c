#include <stdio.h>
int main()
{

	int x = 8;
	printf("x = %d\n",x);
	x>>=2;
	printf("x = %d\n",x);
}
	
