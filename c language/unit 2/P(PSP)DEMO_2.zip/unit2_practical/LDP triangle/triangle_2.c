#include<stdio.h>

void main()
{	
	char a;
	printf("enter char:");
	scanf("%c",&a);
	printf("the character is:\n");
	printf("%c %c %c %c %c %c", a,a,a,a,a);
	printf("%x",&a);
	
}
