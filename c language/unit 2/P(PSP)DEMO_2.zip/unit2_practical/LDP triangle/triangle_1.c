#include<stdio.h>

void main()
{
	
	printf("%s\n", "HELLO");
	printf("%.4s\n","HELLO");
	printf("%.3s\n","HELLO");
	printf("%.2s\n","HELLO");
	printf("%.1s\n","HELLO");
	
}
