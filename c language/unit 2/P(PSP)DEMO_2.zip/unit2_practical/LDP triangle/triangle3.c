#include<stdio.h>

void main()
{
	
	printf("%10s\n", "HELLO");
	printf("%10.4s\n","HELLO");
	printf("%10.3s\n","HELLO");
	printf("%10.2s\n","HELLO");
	printf("%9.1s\n","HELLO");
	
}
