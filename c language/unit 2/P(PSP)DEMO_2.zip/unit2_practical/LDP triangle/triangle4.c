#include<stdio.h>

void main()
{
	char c[5]="nitin";
	printf("%10.1s\n","HELLO");
	printf("%10.2s\n","HELLO");
	printf("%10.3s\n","HELLO");
	printf("%10.4s\n","HELLO");
	printf("%10s\n", "HELLO");
	
	printf("%10.1s\n",c);
	printf("%10.2s\n",c);
	printf("%10.3s\n",c);
	printf("%10.4s\n",c);
	printf("%10s\n",c);
	
	
	
	
}
