#include<stdio.h>

void main()
{
	/*
	printf("%s\n", "*****");
	printf("%.4s\n","*****");
	printf("%.3s\n","*****");
	printf("%.2s\n","*****");
	printf("%.1s\n","*****");
	*/

	printf("%10s\n", "*****");
	printf("%10.4s\n","*****");
/*	printf("%10.3s\n","*****");
	printf("%10.2s\n","*****");
	printf("%10.1s\n","*****");
	*/

}
