#include<stdio.h>

void main()
{
	int a = 10,ans;
	int b = 20;

	/*ans=a++;
	printf("\n ans= %d\n", ans);
	printf("\n a= %d\n", a);
	
	ans=++a;
	printf("\n ans= %d\n", ans);
	printf("\n a= %d\n", a);*/
	
	int z,x;
	z = a * b++;
	
	printf("z= %d\n", z);
	printf("a= %d\n", a);
	printf("b= %d\n", b);
	printf("--------------------\n");
	
	x = a * ++b;
	printf("a= %d\n", a);
	printf("b= %d\n", b);
	printf("x= %d\n", x);
	
}

