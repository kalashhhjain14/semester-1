#include<stdio.h>

int main()
{
	int result;
	result = (1000 >= 100) ? 10 : 100;
	printf("\n result = %d\n", result);

	return 0;

}
