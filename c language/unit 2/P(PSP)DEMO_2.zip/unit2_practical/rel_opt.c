#include<stdio.h>

int main()
{
	int a,b;
	
	printf("\n enter value of a,b :");
	scanf("%d%d",&a,&b); //a=10 , b=5
	
	printf("\n value of a=%d,\n value of b=%d",a,b);
	
	printf("\n a>b      = %d",a>b); //10 > 5 = 1
	printf("\n %d > %d      = %d",a,b,a>b); //10 > 5 = 1
	
	printf("\n a<b      = %d",a<b); //10 < 5 = 0
	printf("\n a>=b     = %d",a>=b);// 10>=5 = 1
	printf("\n a<=b     = %d",a<=b);//10 <=5 = 0
	printf("\n a!=b     = %d",a!=b);//10!=5 = 1
	printf("\n a==b     = %d",a==b); // 10 ==5 = 0
	printf("\n\n\n");
	return 0;
}




