#include<stdio.h>
void main()
{
	int a,b,sum;
	sum=a+b;

	printf("\n enter the value of a :");
	scanf("%d",&a);
	printf("\n enter the value of a :");
	scanf("%d",&a);
	
	printf("\n value of a : %d",a);
	printf("\n value of b : %d",b);
	printf("\n value of sum : %d",sum);


	printf("\n\n\n size of int variable = %d",sizeof(char));
	printf("\n\n\n size of int variable = %d",sizeof(a));






	//return 0;
}
