#include<stdio.h>

void main()
{

	printf("\n 10 != 10 : %d", 10 != 10);	
	printf("\n 10 == 10 : %d", 10 == 10);
	printf("\n 10 <= 100 : %d", 10 <= 100);
	printf("\n 10 > 10 : %d\n", 10 > 10);			
}
