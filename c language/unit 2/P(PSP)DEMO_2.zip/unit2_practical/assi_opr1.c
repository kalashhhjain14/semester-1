#include<stdio.h>

void main()
{

	int a = 10;
	int b = 10;
	int c=a--;
	printf("c = %d\n",c); // c = 10
	printf("a = %d\n",a); // a = 9
	
	int d=--a; //
	printf("d = %d\n",d); // d = 8
	printf("a = %d\n",a); // a = 8
	
	a += 10; // a =a+10
	printf("a = %d\n",a);

	printf("b = %d\n",b);
	b -= 5; // b = b-5
	printf("b = %d\n",b);
	
} 
