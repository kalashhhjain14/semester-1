#include<stdio.h>
void main()
{
	int a,b,sum;
	sum=a+b;
	printf("\n enter the value of a :");
	scanf("%d",&a);
	printf("\n enter the value of b :");
	scanf("%d",&b);

	sum=a+b;

	printf("\n value of a : %d",a);
	printf("\n value of b : %d",b);
	printf("\n value of sum : %d",sum);
	printf("\n");
	//return 0;
}
