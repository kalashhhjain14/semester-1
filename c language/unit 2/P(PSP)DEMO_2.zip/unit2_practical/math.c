// C code to illustrate
// the use of ceil function.
#include <math.h>
#include <stdio.h>

int main()
{
	float val1, val2, val3, val4;

	val1 = 1.6;
	val2 = 1.2;
	val3 = -2.8;
	val4 = -2.3;

	printf(" %d \n", fmax(4,6,2,1,8,9,3));
	
	printf("value1 = %.1lf\n", floor(val1));
	printf("value2 = %.1lf\n", floor(val2));
	printf("value3 = %.1lf\n", ceil(val3));
	printf("value4 = %.1lf\n", ceil(val4));

	return (0);
}
