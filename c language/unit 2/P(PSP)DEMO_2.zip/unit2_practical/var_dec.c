#include<stdio.h>

void main()
{
	int a = 20;
	char b = 'a';
	short c = 1;
	long d = 2569892;
	float e = 2.63;
	double f = 25.3698815882;
	//short g = 124343556456;
	
	printf("%d\n", a);
	printf("%c\n", b);
	printf("%i\n", c);
	printf("%ld\n", d);
	printf("%f\n", e);
	printf("%lf\n", f);	
	//printf("%d\n", g);
	
	
}
