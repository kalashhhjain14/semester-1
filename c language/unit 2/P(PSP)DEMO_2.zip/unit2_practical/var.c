#include<stdio.h>

int main()
{
	int no1; //declaration

	no1=100; // define

	no1=no1+5; //logic

	printf("\n value of no1=%d",no1);
	return 0;
}
