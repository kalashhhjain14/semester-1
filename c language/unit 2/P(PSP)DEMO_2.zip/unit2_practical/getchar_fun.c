#include<stdio.h>

void main()
{
	char c;
	printf("\n enter a char:");
	c = getchar();
	printf("%c\n",c);
	//putchar(c);

}
	