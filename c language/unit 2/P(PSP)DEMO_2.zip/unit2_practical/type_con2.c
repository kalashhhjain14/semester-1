//implicite conversion

#include<stdio.h>

void main()
{
	int a = 2538;
	int b = 2582;
	int c;
	c = a*b;
	
	printf("c = %d\n", c);
}
