#include<stdio.h>

void main()
{
	int a;
	float c;
	
	printf("Enter your Age:");
	scanf("%d",&a);
	printf("\nEnter 12th standard percentage:");
	scanf("%f",&c);
	
	
	printf("\nyour age is %d",a);
	printf("\n Your result is %f\n",c);
	
}
