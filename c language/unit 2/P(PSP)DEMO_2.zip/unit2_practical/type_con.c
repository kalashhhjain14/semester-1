#include<stdio.h>

void main()
{
	int a = 5;
	int b = 2;
	int c;
	float d,e;
	char n='a';
	long int l;
	c = a/b; //2
	d = a/b; //2
	e = (float)a/b; //2.5
	l=(long int)n; //97
	printf("l = %ld\n", l);
	printf("c = %d\n", c);
	printf("d = %f\n", d);
	printf("e = %f\n", e);
}



