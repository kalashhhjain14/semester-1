#include<stdio.h>

int main()
{
	int a,b;
	int sum,sub,mul,div,mod;
	
	printf("\n enter value of a,b :");
	scanf("%d%d",&a,&b);//a=10, b=5
	
	printf("\n value of a=%d,\n value of b=%d",a,b);
	
	sum=a+b;
	sub=a-b;
	mul=a*b;
	div=a/b;
	mod=a%b;
	
	printf("\n a+b = %d",sum);
	printf("\n a-b = %d",sub);
	printf("\n a*b = %d",mul);
	printf("\n a/b = %d",div);
	printf("\n a mod b = %d",mod);

	printf("\n");
	return 0;
}




