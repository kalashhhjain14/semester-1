#include<stdio.h>

int main()
{
	char c1,c2;
	printf("\n enter no1 ::");
	scanf("%c",&c1);
	printf("\n enter no1 ::");
	scanf("%c",&c2);
	printf("%c%c",c1,c2);
	return 0;
}
