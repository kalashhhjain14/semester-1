#include<stdio.h>

void main()
{
	int a=10,b=20,temp;

	printf("\n\n\n\n before swapping a=%d,b=%d",a,b);

	a=a+b;
	b=a-b;
	a=a-b;
	
	/*temp=a;
	a=b;
	b=temp;*/

	printf("\n after swapping a=%d,b=%d \n\n\n",a,b);	
}




