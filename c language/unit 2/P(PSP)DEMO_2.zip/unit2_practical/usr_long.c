#include<stdio.h>
void main()
{
	double a,b,sum;
		
	printf("\n enter the value of a :");
	scanf("%lf",&a);
	printf("\n enter the value of b :");
	scanf("%lf",&b);
	sum=a+b;

	printf("\n value of a : %lf",a);
	printf("\n value of b : %lf",b);
	printf("\n value of sum : %lf",sum);
	printf("\n");
	//return 0;
}
