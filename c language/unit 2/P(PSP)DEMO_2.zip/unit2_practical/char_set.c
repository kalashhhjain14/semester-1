#include<stdio.h>

void main()
{

	int a;
	a = 20;

	printf("%d\n", a);
	printf("\tHELLO WORLDsncjsacj\t");
	printf("\n\"HELLO WORLD\"");
//	printf("\n\'HELLO WORLD\'");
//	printf("HELLO WORLD\r");
	
}
