#include<stdio.h>

int main()
{
	char c1,c2;
	int no1,no2;
	float no3,no4;
	/*printf("\n enter no1 ::");
	scanf("%d",&no1);
	printf("\n enter no1 ::");
	scanf("%d",&no2);*/
	
	printf("\n enter two numbers ::");
	scanf("%c%c%f%f%d%d",&c1,&c2,&no3,&no4,&no1,&no2);
	printf("\n value of no1=%d and no2=%d",no1,no2);
	printf("\n value of no3=%f and no4=%f",no3,no4);
	printf("\n value of no3=%c and no4=%c",c1,c2);
	
	return 0;
}
