#include<stdio.h>

void main()
{
	int a;
	float c;
	char d;
	scanf("%c",&d);
	scanf("%d",&a);
	scanf("%f",&c);
	
	printf("\n%c",d);
	printf("\n%d",a);
	printf("\n%f\n",c);
	
	
}
