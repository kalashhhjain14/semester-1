#include<stdio.h>

int main()
{
	int Num = 20;
	char a = 'a';
	float b = 20.20;

	printf("\n address of int variable = %p \n", &Num);
	printf("\n address of char variable = %p \n", &a);
	printf("\n address of float variable = %p \n", &b);

	return 0;
}
