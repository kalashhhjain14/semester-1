#include<stdio.h>

int main()
{
	int a,b;
	//sum,sub,mul,div,mod;
	
	printf("\n enter value of a,b :");
	scanf("%d%d",&a,&b);
	
	printf("\n value of a=%d,\n value of b=%d",a,b);
	
	printf("\n a+b = %d",a+b);
	printf("\n a-b = %d",a-b);
	printf("\n a*b = %d",a*b);
	printf("\n a/b = %d",a/b);
	printf("\n a mod b = %d",a%b);
	
	return 0;
}