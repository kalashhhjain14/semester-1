
#include<stdio.h>

int main()
{
//	F = ((9/5*C)+32)
//	C = ((F-32)*5)/9


	float f,c;
	printf("\n enter f :");
	scanf("%f",&f);
	
	c=((f-32)*5)/9;
	printf("\n f=%.2f",f);
	printf("\n c=%.2f",c);
	

	printf("\n\n\n");

	printf("\n enter c :");
	scanf("%f",&c);
	
	f = ((9/5*c)+32);
	printf("\n f=%.2f",f);
	printf("\n c=%.2f",c);

	return 0;

}
