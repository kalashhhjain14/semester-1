
#include<stdio.h>

int main()
{
	int ans;
	printf("\n enter a no :");
	scanf("%d",&ans);

	printf("\n entered charcter=%c, ascii value=%d",ans,ans);
	return 0;

}
