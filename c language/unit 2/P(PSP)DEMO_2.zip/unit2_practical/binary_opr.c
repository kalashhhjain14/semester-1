#include<stdio.h>

void main()
{
	int a = 20;
	int b = 30;
	int c,d,e;
	c = a + b;
	d = a - b;
	e = a % b;
	
	printf("c = %d\n", c);	
	printf("d = %d\n", d);
	printf("e = %d\n", e);
	
	
}
