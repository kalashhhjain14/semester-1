
#include<stdio.h>

int main()
{
	char ans;
	printf("\n enter a character :");
	scanf("%c",&ans);

	printf("\n entered charcter=%c, ascii value=%d",ans,ans);
	return 0;

}
