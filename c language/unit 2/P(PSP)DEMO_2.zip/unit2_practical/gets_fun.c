#include<stdio.h>

void main()
{
	char c[30];
	printf("\n enter your name:");
	scanf("%s",&c);
	
	printf("%s\n",c);
	
	//puts(c);

	/*gets(c);
	printf("%s\n",c);
	puts(c);*/

}
